export AWS_REGION=us-east-1
export PROJECT_NAME=support-ticket
export ATTACHMENTS_BUCKET=support-ticket-attachments-1768588809
export INSTANCE_ID=i-02a6c226d3bdf0c5d
export PUBLIC_IP=98.93.248.141
export SECURITY_GROUP_ID=sg-090f543005069429d
export SSH_KEY=~/.ssh/support-ticket-key.pem
